package com.example.demo;

import com.example.demo.model.Person;
import com.example.demo.repository.PersonRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/")
public class DemoController {

	private static final Logger logger = LogManager.getLogger(DemoController.class);

	@Autowired
	private PersonRepository personRepository;

	@GetMapping("/hello")
	public ResponseEntity<String> hello() {
		logger.info("Handling hello request");
		return ResponseEntity.ok("Hello, World!");
	}

	@GetMapping("/enterName")
	public String enterName() {
		return "enterName";
	}

	@GetMapping("/result")
	public String result(@RequestParam(name = "firstName") String firstName,
						 @RequestParam(name = "lastName") String lastName,
						 @RequestParam(name = "phoneNumber") String phoneNumber,
						 Model model) {
		try {
			Person person = new Person(firstName, lastName, phoneNumber);
			personRepository.save(person);
			model.addAttribute("person", person);
			return "result";
		} catch (Exception e) {
			throw new IllegalArgumentException("Invalid input");
		}
	}

	@GetMapping("/allContacts")
	public String allContacts(Model model) {
		List<Person> persons = personRepository.findAll();
		model.addAttribute("persons", persons);
		return "allContacts";
	}

	@ExceptionHandler(IllegalArgumentException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ResponseEntity<ErrorResponse> handleIllegalArgumentException(IllegalArgumentException e) {
		logger.error("Error: ", e);
		ErrorResponse errorResponse = new ErrorResponse(e.getMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	static class ErrorResponse {
		private String errorMessage;

		public ErrorResponse(String errorMessage) {
			this.errorMessage = errorMessage;
		}

		public String getErrorMessage() {
			return errorMessage;
		}

		public void setErrorMessage(String errorMessage) {
			this.errorMessage = errorMessage;
		}
	}
}
